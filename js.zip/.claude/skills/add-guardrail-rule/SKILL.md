---
name: add-guardrail-rule
description: Use when changing what the pipeline is allowed to do — adding or tightening an allow/deny/approval-required rule in the guardrail policy. Triggers on "allow the pipeline to X", "block X", "require approval for X", "add a guardrail".
---

# Add or change a guardrail rule

The guardrail policy (`src/guardrails/policy.ts`, type `PolicyConfig`) is the
single enforcement point for which tools — local or `mcp__<server>__<tool>` —
a pipeline run may use. It is deny-by-default: a tool not matched by
`allowedTools` is denied even with an empty `deniedTools`. Don't change that
default; add narrower rules instead.

## Steps

1. **Identify the exact tool name(s)** the change affects. For MCP tools
   this is `mcp__<server-key>__<tool>`, matching the key used in
   `src/mcp/index.ts` (see [add-mcp-server](../add-mcp-server/SKILL.md) if the
   server isn't registered yet). Prefer the narrowest glob that covers the
   intent — e.g. `mcp__platform__update_*` rather than `mcp__platform__*` if
   only update operations are involved.

2. **Pick the right list**:
   - `allowedTools` — the run may use this tool at all.
   - `deniedTools` — always blocked, even if also matched by `allowedTools`
     (deny wins). Use for anything destructive/irreversible.
   - `requireApproval` — allowed, but `evaluateTool` returns
     `'approval-required'` instead of `'allow'`, so calling code must gate it
     on human/external sign-off before use. Use for changes that are
     reversible but high-blast-radius (e.g. writing to the target platform's
     live config).

3. **Edit [pipeline.policy.example.json](../../../pipeline.policy.example.json)**
   (the documented template all environments derive from) rather than
   hardcoding the rule in `src/pipeline`. Per-environment overrides belong in
   a local `pipeline.policy.json` (gitignored), merged over the example via
   `resolvePolicy` at load time — the example file is what reviewers and new
   environments actually read, so keep it accurate.

4. **Add a test** in `tests/guardrails/policy.test.ts` asserting
   `evaluateTool(policy, '<tool-name>')` returns the expected decision. Cover
   the case your change is meant to prevent, not just the happy path (e.g. if
   you're tightening a rule, assert the previously-allowed call is now
   denied).

5. Run `pnpm check && pnpm typecheck && pnpm test` before committing.
