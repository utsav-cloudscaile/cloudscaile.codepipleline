---
name: add-pipeline-stage
description: Use when adding or changing a stage in the codebase-update pipeline (src/pipeline). Triggers on "add a pipeline stage", "add a step to the pipeline", "change how the pipeline runs a prompt".
---

# Add a pipeline stage

A `PipelineStage` (`src/pipeline/index.ts`) is a named step that drives one
prompt or skill invocation through the Agent SDK's `query()`. `runPipeline`
runs each stage in order and returns a `PipelineStageResult` per stage — add
new stage-execution logic here, not in ad hoc scripts elsewhere in the repo.

Every stage automatically gets `master/INSTRUCTIONS.md` +
`master/skills/*/SKILL.md` (`loadMasterContext`, `src/pipeline/masterContext.ts`)
prepended to its system prompt, on top of the stage's own `prompt` — that's
where repo-agnostic, always-applicable instructions belong (e.g. "match the
target repo's conventions"). Put stage-specific instructions in the stage's
own `prompt`, not in `master/`.

## Steps

1. **Extend or add the stage definition** in `src/pipeline/index.ts`. A stage
   needs at minimum a `name` and a `prompt`; `cwd` is optional (defaults to
   `process.cwd()` — the trigger server, `src/server`, always sets it to the
   target repo's workspace directory). If the stage needs its own tool
   restrictions beyond the run-wide policy, extend `PipelineStage` rather than
   bypassing `PolicyConfig` — see
   [add-guardrail-rule](../add-guardrail-rule/SKILL.md).

2. **Route every tool call through the guardrail policy — this is already
   wired up, don't re-derive it.** `buildCanUseTool` (`src/pipeline/index.ts`)
   calls `evaluateTool(policy, toolName, input)` for every tool attempt and
   denies unless it resolves to `'allow'`; `runStage` also passes
   `policy.allowedTools` / `policy.deniedTools` / `policy.permissionMode`
   straight through to `query()`'s options as a coarse pre-filter. Add/edit
   the pattern in `pipeline.policy.example.json`, not a hand-rolled filter in
   a stage (see [add-guardrail-rule](../add-guardrail-rule/SKILL.md)). If the
   stage calls an MCP server, confirm it's registered first (see
   [add-mcp-server](../add-mcp-server/SKILL.md)). **Do not make `canUseTool`
   return a blanket `{behavior:'allow'}` for anything not
   `'approval-required'`** — that exact change previously broke
   deny-by-default (see `CLAUDE.md`'s "Guardrails are policy, not code"); the
   coarse `allowedTools`/`disallowedTools` pre-filter is not a substitute for
   `canUseTool` actually checking `evaluateTool`'s result.

3. **`'approval-required'` is already handled, don't duplicate it.**
   `buildCanUseTool` gates any tool `evaluateTool` marks
   `'approval-required'` on the `approvalHandler` passed to `runPipeline`
   (default: always denied — no approval channel is wired up yet). Don't add
   a second approval check elsewhere for a new approval-required tool; wire
   a real `approvalHandler` at the call site (e.g. `src/server`) if one is
   needed, or leave it fail-closed until one exists.

4. **Test the stage in isolation** from the actual Agent SDK call: pull any
   pure logic (prompt templating, stage ordering, result parsing) into a
   plain function you can unit test with Vitest, the same way
   `resolvePolicy`/`evaluateTool` are tested in
   `tests/guardrails/policy.test.ts`. Don't make the SDK call itself the unit
   under test — mock/stub it.

5. Run `pnpm check && pnpm typecheck && pnpm test` before committing.
