---
name: add-db-migration
description: Use when changing the MongoDB persistence layer's shape — adding/altering indexes, backfilling or reshaping documents, renaming fields, or any change existing databases must be walked through. Triggers on "add a migration", "backfill X", "change an index", "rename a field in the DB", "bump the schema version".
---

# Add a database migration

Migrations (`src/db/migrations/`, engine in `src/db/migrator.ts`) are
**versioned and forward-only**: each runs at most once per database, applied
in registry order, recorded in the `schema_migrations` collection, serialized
by a lock so concurrent instances can't double-apply. There are no `down`
scripts — to undo something, ship a new migration that rolls forward. Never
edit, reorder, or delete a migration that has been applied anywhere.

## When you do NOT need a migration

- Adding a brand-new **optional** field or a whole new collection: mongoose
  just starts writing it; readers already tolerate its absence. No backfill,
  no migration (unless the field needs an index — see step 2).
- Changes readable under the schema-versioning pattern: documents carry
  `schemaVersion` (`CURRENT_SCHEMA_VERSION`, src/db/models.ts); an absent
  field means version 1. If readers can handle both old and new shapes,
  prefer lazy tolerance over an eager rewrite of millions of documents.

## Steps

1. **Create the migration file** `src/db/migrations/NNNN-kebab-description.ts`
   with the next free four-digit prefix (renumber yours if a merge collides —
   `validateRegistry` rejects duplicate/out-of-order prefixes at startup):

   ```ts
   import type { Migration } from '../migrator.js';

   export const backfillFoo: Migration = {
     id: '0002-backfill-foo', // must equal the filename
     description: 'One line: what and why',
     async up({ db, log }) {
       // ...
     },
   };
   ```

2. **Write `up` idempotently.** A failed run is not recorded and will be
   retried by the next deploy, so a half-applied migration must be safe to
   re-run: use `$set`/`$unset` with filters that exclude already-converted
   docs (e.g. `{ foo: { $exists: false } }`), upserts, or
   `createIndex` (a no-op when the index exists). For **index changes**,
   edit the schema in `src/db/models.ts` first, then have the migration call
   `Model.syncIndexes()` on the affected model (see `0001-baseline-indexes`)
   — `connectMongo` disables autoIndex, so a schema-only index edit does
   nothing until a migration syncs it.

3. **Batch large backfills.** Never `updateMany` an unbounded reshape in one
   shot on a big collection; loop a filtered `bulkWrite` in chunks so the
   migration can be interrupted and resumed:

   ```ts
   const cursor = db.collection('messages').find({ schemaVersion: { $exists: false } });
   for await (const doc of cursor) { /* accumulate ~500 ops, flush, repeat */ }
   ```

4. **Bump `CURRENT_SCHEMA_VERSION`** (src/db/models.ts) only when a
   document's shape changes incompatibly, and make the migration stamp the
   new number on the documents it converts. Readers must keep treating an
   absent `schemaVersion` as 1.

5. **Register it** in `src/db/migrations/index.ts` — append the import and
   the array entry. Unregistered migrations never run; the registry is the
   single source of order.

6. **Test it for real**: `docker compose up -d` then `pnpm migrate:status`
   (should list it as PENDING), `pnpm migrate` (applies it), `pnpm migrate`
   again (must be a no-op — this is the idempotency check), and inspect the
   affected collections plus `schema_migrations`. Add unit tests to
   `tests/db/migrator.test.ts` only if you changed the engine; migration
   files themselves are validated by the registry test already there.

7. Run `pnpm check && pnpm typecheck && pnpm test` before committing.

## Deployment semantics (don't change casually)

Startup applies pending migrations before the server listens
(`MONGODB_AUTO_MIGRATE`, default true) — single-instance deployments get
migrations for free, and a failed migration fails the boot instead of
serving against a half-migrated database. Multi-instance rollouts set
`MONGODB_AUTO_MIGRATE=false` and run `node dist/db/migrate.js up` as a
deploy step before the new instances start; the lock makes either topology
safe, but "migrate in the pipeline" is the one that keeps old pods from
booting against a schema they predate.
