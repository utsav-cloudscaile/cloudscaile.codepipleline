---
name: add-mcp-server
description: Use when registering a new MCP server (a downstream platform the pipeline should be able to configure) in this repo — adds it to src/mcp/index.ts and wires matching guardrail policy entries. Triggers on "add an MCP server", "connect to <platform> over MCP", "register mcp server".
---

# Add an MCP server

This repo calls out to downstream platforms exclusively through MCP servers
registered in [src/mcp/index.ts](../../../src/mcp/index.ts). A server isn't
usable by the pipeline until it also has matching guardrail entries — an MCP
tool with no `allowedTools` glob is denied by default (see
[add-guardrail-rule](../add-guardrail-rule/SKILL.md)).

A fully worked example already lives here: the `git` server
(`src/mcp/git/`, registered in `buildMcpServers`) uses
[`@cyanheads/git-mcp-server`](https://www.npmjs.com/package/@cyanheads/git-mcp-server)
— read it alongside these steps if the abstract version isn't enough.

## Steps

1. **Add the package as a real, exact-pinned dependency** — `pnpm add -E
   <package>@<version>`, not `npx -y <package>@latest` in the registry entry.
   These servers run with real secrets in their environment (a git token, an
   API key) and shell out or make network calls on your behalf; fetching an
   unpinned version from the registry at run time isn't acceptable. `npx`
   then resolves the locally-installed bin with no network fetch.

2. **Register the server** in `src/mcp/index.ts`. `buildMcpServers(config:
   AppConfig): McpServerRegistry` is a function, not a static object — build
   servers that need validated config (secrets, identity) from the
   `AppConfig` it receives, the same way the `git` entry gets
   `config.git.token`/`.email`/`.name`:
   ```ts
   export function buildMcpServers(config: AppConfig): McpServerRegistry {
     return {
       platform: {
         command: 'npx',
         args: ['platform-mcp-server'], // resolves the pinned local dependency
         env: { PLATFORM_API_KEY: config.platform.apiKey },
       },
     };
   }
   ```
   Never hardcode secrets — thread them through `AppConfig` (see
   `src/config/env.ts`'s zod schema and `src/config/types.ts`), not
   `process.env` reached into directly from `src/mcp`.

3. **List the tools it exposes.** If you don't already know them, run the
   server locally and inspect its `tools/list` MCP response — don't guess
   tool names, since the guardrail policy below has to match them exactly.
   One way: `npx @modelcontextprotocol/inspector --cli npx -y <package>
   --method tools/list` (run it from a directory with no `devEngines`
   constraint in its `package.json`, or `npm`/`npx` may refuse — the `git`
   server was inspected this way). Tool names the Agent SDK sees are
   prefixed `mcp__<server-key>__<tool>`, using the same `<server-key>` as the
   registry key above (e.g. `mcp__platform__get_settings`).

4. **Add guardrail entries** in
   [pipeline.policy.example.json](../../../pipeline.policy.example.json):
   - Read-only tools (`get_*`, `list_*`) → `allowedTools`.
   - Destructive or irreversible tools (`delete_*`, anything that mutates
     prod config) → `deniedTools`, or `allowedTools` **and**
     `requireApproval` if it should be reachable but only with sign-off.
     If it's genuinely meant to run unattended anyway, that's the same kind
     of explicit, documented exception as `mcp__git__git_push` — write down
     why, don't just default into it.
   - Don't add a bare `mcp__<server>__*` wildcard unless every tool the
     server exposes is genuinely safe to run unattended — prefer explicit
     per-tool or per-verb globs.

5. **Update `.gitignore`-respecting local config**: if the server needs
   secrets, document the required env var in `pipeline.policy.example.json`'s
   sibling docs or the README, not in a committed `.env`.

6. **Test**: add/extend a `tests/guardrails/policy.test.ts`-style test
   confirming `evaluateTool` returns the expected decision for the new tool
   names (allow / deny / approval-required) — see the existing tests for the
   pattern.

7. Run `pnpm check && pnpm typecheck && pnpm test` before committing.
