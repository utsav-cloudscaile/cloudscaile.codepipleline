Fixture baseline instructions.
